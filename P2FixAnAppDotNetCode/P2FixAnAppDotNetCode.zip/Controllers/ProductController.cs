﻿using System;
using Microsoft.AspNetCore.Mvc;
using P2FixAnAppDotNetCode.Models.Services;
using System.Globalization;
using Microsoft.AspNetCore.Localization;


namespace P2FixAnAppDotNetCode.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductService _productService;

        public ProductController(IProductService productService) => _productService = productService;

        public IActionResult Index()
        {
            var products = _productService.GetAllProducts();

            Console.WriteLine("📦 Vérification des produits envoyés à la vue :");
            foreach (var product in products)
            {
                Console.WriteLine($"- {product.Name} (Stock : {product.Stock})");
            }

            return View(products);
        }
    }
}
