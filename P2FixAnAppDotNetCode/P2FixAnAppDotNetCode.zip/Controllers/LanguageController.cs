﻿using System;
using Microsoft.AspNetCore.Mvc;
using P2FixAnAppDotNetCode.Models.Services;
using P2FixAnAppDotNetCode.Models.ViewModels;

namespace P2FixAnAppDotNetCode.Controllers
{
    public class LanguageController : Controller
    {
        private readonly ILanguageService _languageService;

        public LanguageController(ILanguageService languageService)
        {
            _languageService = languageService;
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult ChangeUiLanguage(LanguageViewModel model, string returnUrl)
        {
            Console.WriteLine("🔍 Requête POST reçue pour changer la langue");

            if (model.Language != null)
            {
                Console.WriteLine($"🌍 Langue sélectionnée : {model.Language}");
                _languageService.ChangeUiLanguage(HttpContext, model.Language);
            }
            else
            {
                Console.WriteLine("🚨 ERREUR : Aucune langue reçue.");
            }

            return Redirect(returnUrl);
        }


    }
}

