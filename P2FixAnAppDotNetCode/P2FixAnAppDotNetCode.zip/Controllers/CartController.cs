﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using P2FixAnAppDotNetCode.Models;
using P2FixAnAppDotNetCode.Models.Services;
using System.Globalization;
using Microsoft.AspNetCore.Localization;




namespace P2FixAnAppDotNetCode.Controllers
{
    public class CartController : Controller
    {
        private readonly ICart _cart;
        private readonly IProductService _productService;

        public CartController(ICart pCart, IProductService productService)=> (_cart, _productService) = (pCart, productService);

        public ViewResult Index()
        {
            ViewBag.Total = _cart.GetTotalValue();
            ViewBag.Average = _cart.GetAverageValue();
            return View(_cart);
        }

        [HttpPost]
        public RedirectToActionResult AddToCart(int productId, int quantity = 1)
        {
            var product = _productService.GetProductById(productId);


            if (product == null)
            {
                return RedirectToAction("Index");
            }

            if (product.Stock < quantity)
            {
                return RedirectToAction("Index");
            }

            _cart.AddItem(product, quantity);

            // 🔥 Mise à jour du stock après ajout au panier
            _productService.UpdateProductStock(productId, product.Stock - quantity);

            Console.WriteLine($"✅ Produit ajouté : {product.Name} (Stock restant : {product.Stock - quantity})");

            return RedirectToAction("Index");
        }

        public RedirectToActionResult RemoveFromCart(int id)
        {
            Product product = _productService.GetAllProducts()
                .FirstOrDefault(p => p.Id == id);

            if (product != null)
            {
                _cart.RemoveLine(product);
            }
            return RedirectToAction("Index");
        }
    }
}
