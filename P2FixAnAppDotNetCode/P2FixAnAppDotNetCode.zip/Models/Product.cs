﻿using System.Collections.Generic;
using System.Globalization;

namespace P2FixAnAppDotNetCode.Models 
{
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }

        private readonly Dictionary<string, string> _descriptions;

        public Product(int id, int stock, double price, string name, string descriptionFr, string descriptionEn, string descriptionEs)
        {
            Id = id;
            Stock = stock;
            Price = price;
            Name = name;

            _descriptions = new Dictionary<string, string>
            {
                { "fr", descriptionFr },
                { "en", descriptionEn },
                { "es", descriptionEs }
            };
        }

        public string Description => _descriptions.TryGetValue(CultureInfo.CurrentCulture.TwoLetterISOLanguageName, out var desc) ? desc : _descriptions["en"];

        public int Stock { get; set; }
        public double Price { get; set; }
    }
}
