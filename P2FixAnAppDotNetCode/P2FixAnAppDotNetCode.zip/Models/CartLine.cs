using System;

namespace P2FixAnAppDotNetCode.Models
{
    public class CartLine
    {
        public int OrderLineId { get; set; }
        public Product Product { get; set; }
        public int Quantity { get; set; }
    }
}
