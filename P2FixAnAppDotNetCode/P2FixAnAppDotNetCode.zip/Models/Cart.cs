﻿using System;
using System.Collections.Generic;
using System.Linq;
using P2FixAnAppDotNetCode.Models;

namespace P2FixAnAppDotNetCode.Models
{   public class Cart : ICart
     {
        public List<CartLine> CartLines { get; set; } = [];
        public void AddItem(Product product, int quantity)
        {
            if (product == null)
            {
                Console.WriteLine("🚨 Erreur : Produit introuvable.");
                return;
            }

            var line = CartLines.FirstOrDefault(l => l.Product.Id == product.Id);

            if (line == null)
            {
                Console.WriteLine($"🛒 Ajout de {quantity} {product.Name} au panier.");
                CartLines.Add(new CartLine { Product = product, Quantity = quantity });
            }
            else
            {
                Console.WriteLine($"🔄 Mise à jour de la quantité de {product.Name} à {line.Quantity + quantity}.");
                line.Quantity += quantity;
            }

            Console.WriteLine($"📦 Total des articles dans le panier : {CartLines.Count}");
        }

        public void RemoveLine(Product product)
        {
            CartLines.RemoveAll(l => l.Product.Id == product.Id);
        }

        public void Clear()
        {
            CartLines.Clear();
        }

        public double GetTotalValue()
        {
            return CartLines.Sum(l => l.Product.Price * l.Quantity);
        }

        public double GetAverageValue()
        {
            int totalItems = CartLines.Sum(line => line.Quantity); 
            return totalItems > 0 ? GetTotalValue() / totalItems : 0;
        }
      }
}




