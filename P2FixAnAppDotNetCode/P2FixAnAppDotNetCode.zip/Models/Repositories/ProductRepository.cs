﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;

namespace P2FixAnAppDotNetCode.Models.Repositories
{
    /// <summary>
    /// The class that manages product data
    /// </summary>
    public class ProductRepository : IProductRepository
    {
        private static List<Product> _products = [];

        public ProductRepository()
        {
            if (_products == null || _products.Count == 0)
            {
                _products = new List<Product>();
                GenerateProductData();
            }
        }


        /// <summary>
        /// Generate the default list of products
        /// </summary>
        private static void GenerateProductData()
        {
            int id = 0;
            _products.Add(new Product(++id, 10, 92.50, "Echo Dot",
                "Enceinte connectée intelligente avec Alexa intégrée.",  // Français
                "Smart speaker with Alexa built-in.",                    // Anglais
                "Altavoz inteligente con Alexa integrada."));            // Espagnol

            _products.Add(new Product(++id, 20, 9.99, "Anker 3ft USB Cable",
                "Câble USB ultra-résistant pour charge rapide.",        // Français
                "Ultra-durable USB cable for fast charging.",          // Anglais
                "Cable USB ultrarresistente para carga rápida."));     // Espagnol

            _products.Add(new Product(++id, 30, 69.99, "JVC HAFX8R Headphone",
                "Écouteurs intra-auriculaires JVC HAFX8R Riptidz, son clair et puissant.",
                "JVC HAFX8R Riptidz in-ear headphones, clear and powerful sound.",
                "Auriculares intrauditivos JVC HAFX8R Riptidz, sonido claro y potente."));

            _products.Add(new Product(++id, 40, 32.50, "VTech CS6114 DECT 6.0",
                "Téléphone sans fil VTech CS6114 DECT 6.0 avec identification de l'appelant.",
                "VTech CS6114 DECT 6.0 Cordless Phone",
                "Teléfono inalámbrico VTech CS6114 DECT 6.0."));

            _products.Add(new Product(++id, 1, 895.00, "NOKIA OEM BL-5J",
                "Batterie d'origine NOKIA OEM BL-5J, haute autonomie.",
                "Original NOKIA OEM BL-5J battery, high autonomy.",
                "Batería original NOKIA OEM BL-5J, alta autonomía."));
        }


        /// <summary>
        /// Get all products from the inventory
        /// </summary>


        public List<Product> GetAllProducts()
        {
            return _products; // ✅ Ne recrée pas la liste, garde les mises à jour
        }


        public Product GetProductById(int id)
        {
            var product = _products.FirstOrDefault(p => p.Id == id);

            if (product == null)
            {
                Console.WriteLine($"🚨 ERREUR : Aucun produit trouvé avec ID {id}.");
            }
            else
            {
                Console.WriteLine($"✅ Produit trouvé : {product.Name} (ID: {product.Id})");
            }

            return product;
        }





        /// <summary>
        /// Update the stock of a product in the inventory by its id
        /// </summary>
        public void UpdateProductStocks(int productId, int quantityToRemove)
        {
            var product = _products.FirstOrDefault(p => p.Id == productId);

            if (product == null)
            {
                Console.WriteLine($"🚨 ERREUR : Impossible de mettre à jour le stock, produit ID {productId} introuvable.");
                return;
            }

            if (product.Stock < quantityToRemove)
            {
                Console.WriteLine($"⚠️ Stock insuffisant pour {product.Name}. Stock actuel : {product.Stock}, demande : {quantityToRemove}");
                return;
            }

            product.Stock -= quantityToRemove;
            Console.WriteLine($"📦 Stock mis à jour : {product.Name} (Stock restant : {product.Stock})");
        }


    }
}
