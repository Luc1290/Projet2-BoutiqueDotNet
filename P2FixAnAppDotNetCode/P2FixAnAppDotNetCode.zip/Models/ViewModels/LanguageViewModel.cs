﻿namespace P2FixAnAppDotNetCode.Models.ViewModels
{
    public class LanguageViewModel
    {
        public string Language { get; set; }

    }
}
