﻿namespace P2FixAnAppDotNetCode.Models.Services
{
    public interface IOrderService
    {
        void SaveOrder(Order order);
    }
}
