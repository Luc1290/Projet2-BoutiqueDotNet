﻿using System;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Localization;

namespace P2FixAnAppDotNetCode.Models.Services
{
    /// <summary>
    /// Provides services method to manage the application language
    /// </summary>
    public class LanguageService : ILanguageService
    {
        /// <summary>
        /// Set the UI language
        /// </summary>
        public void ChangeUiLanguage(HttpContext context, string language)
        {
            string culture = SetCulture(language);
            UpdateCultureCookie(context, culture);
            Console.WriteLine($"🌍 Langue changée : {culture}");
        }



        /// <summary>
        /// Set the culture
        /// </summary>
        public string SetCulture(string language)
        {
            Console.WriteLine($"🛠️ Tentative d'application de la langue : {language}");
            language = language.ToLower();

            language = language switch
            {
                var l when l.Contains("spanish") => "es-ES",
                var l when l.Contains("english") => "en-GB",
                var l when l.Contains("french") => "fr-FR",
                _ => language
            };

            return language switch
            {
                "fr" or "fr-fr" or "fr-FR" => "fr-FR",
                "en" or "en-gb" or "en-us" or "en-US" or "en-GB" => "en-GB",
                "es" or "es-es" or "es-ES" => "es-ES",
                _ => "en-GB"
            };
        }



        /// <summary>
        /// Update the culture cookie
        /// </summary>
        public void UpdateCultureCookie(HttpContext context, string culture)
        {
            var cookieValue = CookieRequestCultureProvider.MakeCookieValue(new RequestCulture(culture));
            context.Response.Cookies.Append(CookieRequestCultureProvider.DefaultCookieName, cookieValue);
            Console.WriteLine($"🔍 Cookie de langue mis à jour : {cookieValue}");
        }

    }
}
