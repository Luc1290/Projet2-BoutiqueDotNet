﻿using System;
using System.Collections.Generic;
using System.Linq;
using P2FixAnAppDotNetCode.Models.Repositories;

namespace P2FixAnAppDotNetCode.Models.Services
{
    /// <summary>
    /// This class provides services to manages the products
    /// </summary>
    public class ProductService : IProductService
    {
        private readonly IProductRepository _productRepository;
        private readonly IOrderRepository _orderRepository;

        public ProductService(IProductRepository productRepository, IOrderRepository orderRepository) => (_productRepository, _orderRepository) = (productRepository, orderRepository);

        /// <summary>
        /// Get all product from the inventory
        /// </summary>
        public List<Product> GetAllProducts()
        {
            return _productRepository.GetAllProducts();
        }

        /// <summary>
        /// Get a product form the inventory by its id
        /// </summary>
        public Product GetProductById(int id)
        {
            var product = _productRepository.GetAllProducts().FirstOrDefault(p => p.Id == id);

            if (product == null)
            {
                Console.WriteLine($"Erreur: Produit ID {id} introuvable.");
            }

            return product;
        }


        /// <summary>
        /// Update the quantities left for each product in the inventory depending of ordered the quantities
        /// </summary>
        public void UpdateProductQuantities(Cart cart)
        {
            foreach (var line in cart.CartLines)
            {
                _productRepository.UpdateProductStocks(line.Product.Id, line.Quantity);
            }
        }


        public void UpdateProductStock(int productId, int newStock)
        {
            var product = _productRepository.GetProductById(productId);

            if (product == null)
            {
                Console.WriteLine($"🚨 ERREUR : Produit ID {productId} introuvable.");
                return;
            }

            product.Stock = newStock;
            Console.WriteLine($"✅ Stock mis à jour via `ProductService` : {product.Name} -> {newStock} restant.");
        }






    }
}
