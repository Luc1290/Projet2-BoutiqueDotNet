﻿using System;
using System.Resources;
using System.Reflection;
using System.Globalization;

namespace P2FixAnAppDotNetCode.Resources.Models.ViewModels
{
    public static class Order
    {
        private static readonly ResourceManager resourceManager = new (
            "P2FixAnAppDotNetCode.Resources.Models.ViewModels.Order",
            Assembly.GetExecutingAssembly());

        private static CultureInfo resourceCulture = CultureInfo.CurrentCulture;

        static Order()
        {
            resourceCulture = CultureInfo.CurrentCulture;
        }

        public static CultureInfo ResourceCulture
        {
            get => resourceCulture;
            set
            {
                if (value != null)
                {
                    resourceCulture = value;
                }
            }
        }

        public static string ErrorMissingName => resourceManager.GetString("ErrorMissingName", resourceCulture) ?? "ErrorMissingName";
        public static string ErrorMissingAddress => resourceManager.GetString("ErrorMissingAddress", resourceCulture) ?? "ErrorMissingAddress";
        public static string ErrorMissingCity => resourceManager.GetString("ErrorMissingCity", resourceCulture) ?? "ErrorMissingCity";
        public static string ErrorMissingCountry => resourceManager.GetString("ErrorMissingCountry", resourceCulture) ?? "ErrorMissingCountry";
    }
}
